// Copyright BenAGue 2014
// version 2 of my Flat UI Login Forms. (Still like v1 better :P)