/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm;

/**
 *
 * @author Mindsoft
 */
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import org.apache.commons.net.ftp.FTPClient;
public class Ftpcon {
    FTPClient client = new FTPClient();
    FileInputStream fis = null;
    boolean status;
     boolean success;

public boolean upload(File file){
   try{
//           client.enterLocalPassiveMode();
            client.connect("ftp.drivehq.com");
       
            client.login("revarace2023cs01", "Success@cs01");
            client.enterLocalPassiveMode();
            
             fis = new FileInputStream(file);
             
             status= client.storeFile(" /ke/"+file.getName(), fis);
       
             client.logout();
             fis.close();
    
}
catch(Exception e){
    System.out.println(e);
}
        if(status){
             System.out.println("success");
             return true;
        }
        else{
            System.out.println("failed");
            return false;
          
        }
    
} 
public boolean filedownload(String fname)
{
    

    try
    {
        client.connect("ftp.drivehq.com");
       
            client.login("revarace2023cs01", "Success@cs01");
            client.enterLocalPassiveMode();
            
        File localfile = new File("D:\\"+fname);
            OutputStream outputStream = new BufferedOutputStream(new FileOutputStream(localfile));
            success = client.retrieveFile(" /ke/"+fname, outputStream);
            outputStream.close();
    }catch(Exception e)
    {
        e.printStackTrace();
    }
     if(success){
             System.out.println("success");
             return true;
        }
        else{
            System.out.println("failed");
            return false;
          
}

   
}
}
