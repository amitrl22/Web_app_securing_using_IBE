/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package network;

/**
 *
 * @author Shekar
 */
public class Constant {
     public static String file="D:\\";
    
}
